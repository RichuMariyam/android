package com.example.registrationrichu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText full_name,email_id,password;
    Button register_btn;
    LinearLayout main_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        full_name=findViewById(R.id.full_name);
        email_id=findViewById(R.id.email_id);
        password=findViewById(R.id.password);
        register_btn=findViewById(R.id.register_btn);
        main_layout=findViewById(R.id.main_layout);
        register_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                full_name.setError(null);
                email_id.setError(null);
                password.setError(null);
                String password_regex="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{4,}$";
                String full_name_text=full_name.getText().toString();
                String email_id_text=email_id.getText().toString();
                String password_text=password.getText().toString();
                if(full_name_text.equals(""))
                {
                    full_name.requestFocus();
                    full_name.setError("Please Enter full_name!!");
                }
                else if(email_id_text.equals(""))
                {
                    email_id.requestFocus();
                    email_id.setError("Please enter email_id!!");
                }
                else if(!Patterns.EMAIL_ADDRESS.matcher(email_id_text).matches())
                {
                    email_id.requestFocus();
                    email_id.setError("Please enter a valid email_id!!");
                }
                else if(!password_text.matches(password_regex))
                {
                    password.requestFocus();
                    password.setError("Password should contain-\n a digit must occur at least once \n a lower case letter must occur at least once \n an uppercase letter occur at least once \n a special character like @#$%^&+=\n No blank spaces allowed \n at least 6 characterr");
                }
                else {
                    SharedPreferences pref=getSharedPreferences("register_data",MODE_PRIVATE);
                    SharedPreferences.Editor pref_edit=pref.edit();
                    pref_edit.putString("reg_full_name",full_name_text);
                    pref_edit.putString("reg_email_id",email_id_text);
                    pref_edit.putString("reg_password",password_text);
                    pref_edit.apply();
                    Intent intent=new Intent(getApplicationContext(),IntendS2.class);
                    startActivity(intent);
                }
            }
        });

    }
}