package com.example.registrationrichu;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class IntendS2 extends AppCompatActivity{
    TextView full_name_result,email_id_result,password_result;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intend_s2);
        full_name_result=findViewById(R.id.full_name_result);
        email_id_result=findViewById(R.id.email_id_result);
        password_result=findViewById(R.id.password_result);
        SharedPreferences pref=getSharedPreferences("register_data",MODE_PRIVATE);
        String name=pref.getString("reg_full_name","Not Available!!");
        String email=pref.getString("reg_email_id","Not Available!!");
        String password=pref.getString("reg_password","Not Available!!");
        full_name_result.setText(name);
        email_id_result.setText(email);
        password_result.setText(password);



    }


}
